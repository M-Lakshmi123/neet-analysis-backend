import React, { useState, useEffect, useMemo } from 'react';
import { API_URL, buildQueryParams } from '../utils/apiHelper';
import LoadingTimer from './LoadingTimer';
import {
    Chart as ChartJS,
    CategoryScale,
    LinearScale,
    BarElement,
    Title,
    Tooltip,
    Legend
} from 'chart.js';
import { Bar } from 'react-chartjs-2';
import ChartDataLabels from 'chartjs-plugin-datalabels';

ChartJS.register(
    CategoryScale,
    LinearScale,
    BarElement,
    Title,
    Tooltip,
    Legend,
    ChartDataLabels
);

const TargetVsAchieved = ({ filters }) => {
    const [allTargets, setAllTargets] = useState([]);
    const [studentResults, setStudentResults] = useState([]);
    const [examStats, setExamStats] = useState([]);
    const [loading, setLoading] = useState(true);
    const [selectedThreshold, setSelectedThreshold] = useState('>= 550');

    const thresholds = useMemo(() => [
        { label: '>= 710', key: '>= 710M', statsKey: 'T_710', value: 710 },
        { label: '>= 700', key: '>= 700M', statsKey: 'T_700', value: 700 },
        { label: '>= 685', key: '>= 685M', statsKey: 'T_685', value: 685 },
        { label: '>= 655', key: '>= 655M', statsKey: 'T_655', value: 655 },
        { label: '>= 640', key: '>= 640M', statsKey: 'T_640', value: 640 },
        { label: '>= 595', key: '>= 595M', statsKey: 'T_595', value: 595 },
        { label: '>= 570', key: '>= 570M', statsKey: 'T_570', value: 570 },
        { label: '>= 550', key: '>= 550M', statsKey: 'T_550', value: 550 },
        { label: '>= 530', key: '>= 530M', statsKey: 'T_530', value: 530 },
        { label: '>= 490', key: '>= 490M', statsKey: 'T_490', value: 490 },
        { label: '>= 480', key: '>= 480M', statsKey: 'T_480', value: 480 },
        { label: '>= 450', key: '>= 450M', statsKey: 'T_450', value: 450 },
        { label: '>= 400', key: '>= 400M', statsKey: 'T_400', value: 400 },
        { label: '>= 370', key: '>= 370M', statsKey: 'T_370', value: 370 },
        { label: '>= 350', key: '>= 350M', statsKey: 'T_350', value: 350 },
        { label: '>= 300', key: '>= 300M', statsKey: 'T_300', value: 300 },
        { label: '>= 200', key: '>= 200M', statsKey: 'T_200', value: 200 },
    ], []);

    useEffect(() => {
        const fetchTargets = async () => {
            try {
                const year = filters.academicYear || '2026';
                const res = await fetch(`${API_URL}/api/targets?academicYear=${year}`);
                const data = await res.json();
                setAllTargets(data);
            } catch (error) {
                console.error("Failed to fetch targets:", error);
            }
        };
        fetchTargets();
    }, [filters.academicYear]);

    useEffect(() => {
        const fetchData = async () => {
            setLoading(true);
            try {
                const queryParams = buildQueryParams(filters).toString();
                const marksPromise = fetch(`${API_URL}/api/analysis-report?${queryParams}`).then(r => r.json());
                const statsPromise = fetch(`${API_URL}/api/exam-stats?${queryParams}`).then(r => r.json());
                const [marksData, statsData] = await Promise.all([marksPromise, statsPromise]);
                setStudentResults(marksData.students || []);
                setExamStats(statsData || []);
            } catch (error) {
                console.error("Failed to fetch performance data:", error);
            } finally {
                setLoading(false);
            }
        };
        fetchData();
    }, [filters]);

    const aggregatedTarget = useMemo(() => {
        if (!allTargets.length) return {};
        let filtered = allTargets;

        // Filter by Campus - handle 'All', 'All Selected', '__ALL__' or empty
        const campusFilter = filters.campus || [];
        const isAllCampus = campusFilter.length === 0 ||
            campusFilter.some(c => ['All', 'All Selected', 'ALL SELECTED', '__ALL__'].includes(c));

        if (!isAllCampus) {
            filtered = filtered.filter(t =>
                t.NAME_OF_THE_CAMPUS && campusFilter.some(c => t.NAME_OF_THE_CAMPUS.trim().toUpperCase() === c.trim().toUpperCase())
            );
        }

        // Filter by Stream - handle 'All', '__ALL__' or empty
        const streamFilter = filters.stream || [];
        const isAllStream = streamFilter.length === 0 ||
            streamFilter.some(s => ['All', '__ALL__'].includes(s));

        if (!isAllStream) {
            filtered = filtered.filter(t => {
                const tStreamRaw = t.Stream ? t.Stream.trim().toUpperCase() : '';
                const tStreamNorm = tStreamRaw.replace(/_/g, ' ');
                return streamFilter.some(sf => {
                    const sfRaw = sf ? sf.trim().toUpperCase() : '';
                    const sfNorm = sfRaw.replace(/_/g, ' ');
                    return (
                        tStreamRaw === sfRaw ||
                        tStreamNorm === sfNorm ||
                        (sfNorm.includes('SR ELITE') && tStreamNorm.includes('SR ELITE')) ||
                        (sfNorm.includes('SR AIIMS') && tStreamNorm.includes('SR AIIMS')) ||
                        (sfNorm.includes('JR ELITE') && tStreamNorm.includes('JR ELITE')) ||
                        (sfNorm.includes('JR AIIMS') && tStreamNorm.includes('JR AIIMS')) ||
                        (sfNorm.includes('LTC') && tStreamNorm.includes('LTC'))
                    );
                });
            });
        }

        const result = {};
        thresholds.forEach(th => {
            let hasValidTarget = false;
            let sum = 0;
            filtered.forEach(row => {
                const val = row[th.key];
                if (val !== null && val !== undefined && val !== '' && !isNaN(Number(val))) {
                    hasValidTarget = true;
                    sum += Number(val);
                }
            });
            result[th.key] = hasValidTarget ? sum : '';
        });
        return result;
    }, [allTargets, filters, thresholds]);

    const achievedCounts = useMemo(() => {
        if (!studentResults.length) return {};
        const counts = {};
        thresholds.forEach(th => {
            const count = studentResults.filter(s => Number(s.tot) >= th.value).length;
            counts[th.key] = count;
        });
        return counts;
    }, [studentResults, thresholds]);

    const campusDisplayText = useMemo(() => {
        const campusFilter = filters.campus || [];
        const isAll = campusFilter.length === 0 ||
            campusFilter.some(c => ['All', 'All Selected', 'ALL SELECTED', '__ALL__'].includes(c));

        if (isAll || campusFilter.length > 1) {
            return "ALL CAMPUSES";
        }
        return campusFilter[0];
    }, [filters.campus]);

    const detailStudents = useMemo(() => {
        const thresholdValue = thresholds.find(t => t.label === selectedThreshold)?.value || 0;
        return studentResults
            .filter(s => Number(s.tot) >= thresholdValue)
            .sort((a, b) => b.tot - a.tot);
    }, [studentResults, selectedThreshold]);

    const selectedThInfo = thresholds.find(t => t.label === selectedThreshold);
    const hasTargetForSelected = aggregatedTarget[selectedThInfo?.key] !== undefined && 
                                 aggregatedTarget[selectedThInfo?.key] !== null && 
                                 aggregatedTarget[selectedThInfo?.key] !== '';
    const targetVal = hasTargetForSelected ? Number(aggregatedTarget[selectedThInfo?.key]) : 0;
    const achievedVal = achievedCounts[selectedThInfo?.key] || 0;

    const chartData = {
        labels: ['Target', 'Achieved'],
        datasets: [
            {
                data: [targetVal, achievedVal],
                backgroundColor: [
                    '#003366', // Dark Target Blue
                    (!hasTargetForSelected || achievedVal >= targetVal) ? '#006600' : '#FFC000' // Green or Amber
                ],
                borderRadius: 12,
                barThickness: 80,
                datalabels: {
                    formatter: (val, ctx) => {
                        if (ctx.dataIndex === 0 && !hasTargetForSelected) {
                            return 'No Target';
                        }
                        return val;
                    },
                    color: ['white', (!hasTargetForSelected || achievedVal >= targetVal) ? 'white' : 'black'],
                    font: { weight: '900', size: 16 },
                    anchor: 'center',
                    align: 'center'
                }
            }
        ]
    };

    const chartOptions = {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
            legend: { display: false },
            tooltip: { enabled: true },
            datalabels: { display: true }
        },
        scales: {
            y: {
                beginAtZero: true,
                grid: { color: 'rgba(0,0,0,0.05)' },
                ticks: { color: '#000', font: { weight: 'bold', size: 12 } }
            },
            x: {
                grid: { display: false },
                ticks: { color: '#000', font: { weight: '900', size: 14 } }
            }
        },
        elements: {
            bar: {
                borderWidth: 2,
                borderColor: 'rgba(255,255,255,0.2)'
            }
        }
    };

    return (
        <div className="target-analysis-final">
            <LoadingTimer isLoading={loading} />

            <div className="full-width-glass target-section">
                <div className="glass-header">
                    TARGETS GIVEN BY CO_HYD({filters.stream && filters.stream.length > 0 && !filters.stream.includes('__ALL__') ? filters.stream.join(', ') : 'ALL STREAMS'})
                </div>
                <div className="glass-grid">
                    {thresholds.map(th => {
                        const val = aggregatedTarget[th.key];
                        const displayVal = (val !== undefined && val !== null && val !== '') ? val : '';
                        return (
                            <div key={th.label} className="glass-cell">
                                <div className="label">{th.label}</div>
                                <div className="value">{displayVal}</div>
                            </div>
                        );
                    })}
                </div>
            </div>

            <div className="full-width-glass achieved-section">
                <div className="glass-header">TOTAL ACHIEVED BY {campusDisplayText}</div>
                <div className="glass-grid">
                    {thresholds.map(th => {
                        const target = aggregatedTarget[th.key];
                        const hasTarget = target !== undefined && target !== null && target !== '';
                        const achieved = (achievedCounts[th.key] !== undefined && achievedCounts[th.key] !== null) ? achievedCounts[th.key] : 0;
                        const isSelected = selectedThreshold === th.label;
                        
                        let cardStatusClass = 'no-target';
                        if (hasTarget) {
                            cardStatusClass = achieved >= Number(target) ? 'match-green' : 'match-red';
                        } else if (achieved > 0) {
                            cardStatusClass = 'match-green';
                        }

                        return (
                            <div
                                key={th.label}
                                className={`glass-cell interactive ${cardStatusClass} ${isSelected ? 'active-ring' : ''}`}
                                onClick={() => setSelectedThreshold(th.label)}
                            >
                                <div className="label">{th.label}</div>
                                <div className="value">{achieved}</div>
                            </div>
                        );
                    })}
                </div>
            </div>

            <div className="split-view">
                <div className="glass-card chart-side">
                    <div className="card-header-dark">Comparison for {selectedThreshold}</div>
                    <div className="chart-area">
                        <Bar data={chartData} options={chartOptions} />
                    </div>
                </div>

                <div className="glass-card table-side">
                    <div className="card-header-dark">
                        Student List ({detailStudents.length})
                    </div>
                    <div className="table-scroll">
                        <table className="modern-table">
                            <thead>
                                <tr>
                                    <th>STUDENT</th>
                                    <th>CAMPUS</th>
                                    <th className="text-center">TOT</th>
                                    <th className="text-center">AIR</th>
                                    <th className="text-center">BOT</th>
                                    <th className="text-center">ZOO</th>
                                    <th className="text-center">PHY</th>
                                    <th className="text-center">CHE</th>
                                    <th className="text-center">EXAMS</th>
                                </tr>
                            </thead>
                            <tbody>
                                {detailStudents.map((s, idx) => (
                                    <tr key={s.STUD_ID || idx}>
                                        <td className="bold-black">{s.name}</td>
                                        <td className="campus-text">{s.campus}</td>
                                        <td className="text-center score-high">{Number(s.tot).toFixed(1)}</td>
                                        <td className="text-center">{Math.round(s.air) || '-'}</td>
                                        <td className="text-center">{Number(s.bot || 0).toFixed(0)}</td>
                                        <td className="text-center">{Number(s.zoo || 0).toFixed(0)}</td>
                                        <td className="text-center">{Number(s.phy || 0).toFixed(0)}</td>
                                        <td className="text-center">{Number(s.che || 0).toFixed(0)}</td>
                                        <td className="text-center font-bold text-blue-600">{s.t_app}</td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <style jsx>{`
                .target-analysis-final {
                    padding: 16px 24px;
                    display: flex;
                    flex-direction: column;
                    gap: 16px;
                    background: #f0f2f5;
                    font-family: 'Comic Sans MS', 'Comic Sans', cursive;
                }
                .full-width-glass {
                    background: rgba(255, 255, 255, 0.85);
                    backdrop-filter: blur(12px);
                    border: 1px solid rgba(0, 0, 102, 0.1);
                    border-radius: 12px;
                    box-shadow: 0 4px 20px 0 rgba(0, 0, 102, 0.05);
                    overflow: hidden;
                }
                .glass-header {
                    background: #EBF1DE;
                    color: #000066;
                    padding: 8px 16px;
                    font-size: 0.85rem;
                    font-weight: 900;
                    letter-spacing: 1px;
                    border-bottom: 2px solid #000066;
                }
                .glass-grid {
                    display: grid;
                    grid-template-columns: repeat(17, minmax(0, 1fr));
                }
                .glass-cell {
                    padding: 8px 2px;
                    text-align: center;
                    border-right: 1px solid rgba(0,0,102,0.1);
                    min-width: 0;
                }
                .glass-cell:last-child { border: none; }
                .label {
                    font-size: 0.72rem;
                    font-weight: 900;
                    color: #000066;
                    margin-bottom: 2px;
                    white-space: nowrap;
                    overflow: hidden;
                    text-overflow: ellipsis;
                }
                .value {
                    font-size: 1.1rem;
                    font-weight: 950;
                    color: #000066;
                    min-height: 24px;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                }
                
                .match-green { background: #006600 !important; border: 1px solid rgba(255,255,255,0.1) !important; }
                .match-green .value, .match-green .label { color: #fff !important; }
                
                .match-red { background: #FFC000 !important; border: 1px solid rgba(0,0,0,0.1) !important; }
                .match-red .value, .match-red .label { color: #000 !important; }

                .no-target { background: rgba(0, 0, 102, 0.04) !important; border: 1px solid rgba(0,0,102,0.08) !important; }
                .no-target .value, .no-target .label { color: #000066 !important; }
                
                .interactive { cursor: pointer; transition: 0.3s; }
                .interactive:hover { transform: scale(1.02); z-index: 10; box-shadow: 0 5px 15px rgba(0,0,0,0.1); }
                .active-ring { border: 2px solid #000066 !important; }

                .split-view {
                    display: grid;
                    grid-template-columns: 30% 70%;
                    gap: 16px;
                }
                .glass-card {
                    background: rgba(255, 255, 255, 0.85);
                    backdrop-filter: blur(10px);
                    border-radius: 16px;
                    border: 1px solid rgba(0,0,102,0.1);
                    box-shadow: 0 8px 30px rgba(0,0,102,0.06);
                    overflow: hidden;
                }
                .card-header-dark {
                    background: #EBF1DE;
                    color: #000066;
                    padding: 10px 20px;
                    font-weight: 900;
                    font-size: 1rem;
                    border-bottom: 2px solid #000066;
                }
                .chart-side {
                    height: 480px;
                }
                .chart-area {
                    height: calc(100% - 40px);
                    padding: 15px 15px 10px;
                }
                .table-side {
                    height: 480px;
                    display: flex;
                    flex-direction: column;
                }
                .table-scroll { flex: 1; overflow-y: auto; }
                
                .modern-table { width: 100%; border-collapse: collapse; background: #fff; }
                .modern-table th {
                    background: #EBF1DE;
                    padding: 10px 14px;
                    font-size: 0.75rem;
                    font-weight: 900;
                    color: #000066;
                    text-align: left;
                    border-bottom: 2px solid #000066;
                    position: sticky; top: 0;
                }
                .modern-table td {
                    padding: 8px 14px;
                    border-bottom: 1px solid rgba(0,0,102,0.1);
                    font-size: 0.88rem;
                    color: #000066;
                    font-family: 'Inter', system-ui, -apple-system, sans-serif;
                }
                .bold-black { font-weight: 950; color: #000066 !important; font-family: 'Inter', system-ui, sans-serif; }
                .campus-text { opacity: 0.7; font-size: 0.78rem; white-space: nowrap; color: #000066; font-family: 'Inter', system-ui, sans-serif; }
                .score-high { color: #000066 !important; font-weight: 950; }
                
                tr:hover { background: rgba(0,0,0,0.02); }
            `}</style>
        </div>
    );
};

export default TargetVsAchieved;
