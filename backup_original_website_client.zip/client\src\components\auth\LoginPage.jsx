import React, { useState, useEffect } from 'react';
import { auth, db } from '../../firebase';
import { signInWithEmailAndPassword, signOut } from 'firebase/auth';
import { doc, getDoc } from 'firebase/firestore';
import { useNavigate, Link } from 'react-router-dom';
import { useAuth } from './AuthProvider';
import { LogIn, Mail, Lock, ArrowRight, ShieldCheck, Award, TrendingUp, Users, School } from 'lucide-react';
import { AnimatePresence } from 'framer-motion';
import Toast from '../Toast';
import Modal from '../Modal';

const LoginPage = () => {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState('');
    const [currentSlide, setCurrentSlide] = useState(0);
    const [toast, setToast] = useState(null);
    const [modal, setModal] = useState({ isOpen: false, title: '', message: '', type: 'info' });
    const navigate = useNavigate();
    const { userData, currentUser } = useAuth();

    useEffect(() => {
        // If the user lands here but is actually authenticated but NOT approved
        if (currentUser && userData && !userData.isApproved && !modal.isOpen && currentUser.email !== "yenjarappa.s@varsitymgmt.com") {
            setModal({
                isOpen: true,
                title: 'Approval Pending',
                message: `Hello ${userData.name || 'Principal'}, your account is currently awaiting administrator approval. You will be able to access the dashboard once access is granted.`,
                type: 'info'
            });
            signOut(auth);
            sessionStorage.removeItem('NEET_SESSION_ACTIVE');
        }
    }, [currentUser, userData]);

    const showToast = (message, type = 'error') => {
        setToast({ message, type });
    };

    const slides = [
        {
            image: "/brooke-cagle-g1Kr4Ozfoac-unsplash.jpg",
            quote: "TRANSFORMING DREAMS INTO REALITY THROUGH EXCELLENCE",
            animClass: "anim-fade",
            stats: [
                { icon: <Users size={20} />, label: "NEET QUALIFIED", value: "85,000+" },
                { icon: <Award size={20} />, label: "TOP AIR RANKS", value: "AIR 1, 2, 3" }
            ]
        },
        {
            image: "/pang-yuhao-_kd5cxwZOK4-unsplash.jpg",
            quote: "GLOBAL STANDARDS IN MEDICAL EDUCATION",
            animClass: "anim-zoom",
            stats: [
                { icon: <School size={20} />, label: "LEGACY OF TRUST", value: "38 YEARS" },
                { icon: <TrendingUp size={20} />, label: "MBBS SEATS", value: "25,000+" }
            ]
        },
        {
            image: "/david-schultz-kM97y3aWWQw-unsplash.jpg",
            quote: "WHERE DETERMINATION MEETS WORLD-CLASS MENTORSHIP",
            animClass: "anim-slide",
            stats: [
                { icon: <Users size={20} />, label: "ASPIRING DOCTORS", value: "2 LAC PROJECTED" },
                { icon: <Award size={20} />, label: "STATE TOPPERS", value: "150+" }
            ]
        }
    ];

    useEffect(() => {
        const interval = setInterval(() => {
            setCurrentSlide(prev => (prev + 1) % slides.length);
        }, 5000);
        return () => clearInterval(interval);
    }, []);

    const handleLogin = async (e) => {
        e.preventDefault();
        setError('');
        setLoading(true);

        try {
            // Master Admin Credentials Check
            const ADMIN_EMAIL = "yenjarappa.s@varsitymgmt.com";
            const ADMIN_PASSWORD = "Neet@123#";

            if (email === ADMIN_EMAIL && password !== ADMIN_PASSWORD) {
                showToast("Invalid admin password.");
                setLoading(false);
                return;
            }

            // Perform Login
            sessionStorage.setItem('NEET_SESSION_ACTIVE', 'true');
            const userCredential = await signInWithEmailAndPassword(auth, email, password);
            const user = userCredential.user;

            // Check if user is Approved (Principal logic)
            if (email !== ADMIN_EMAIL) {
                const userDoc = await getDoc(doc(db, "users", user.uid));
                if (userDoc.exists()) {
                    const data = userDoc.data();
                    if (!data.isApproved) {
                        // Show Pending Approval Modal
                        setModal({
                            isOpen: true,
                            title: 'Approval Pending',
                            message: `Hello ${data.name || 'Principal'}, your account registration is successful, but it is currently awaiting administrator approval. You will receive a notification once access is granted.`,
                            type: 'info'
                        });
                        await signOut(auth);
                        sessionStorage.removeItem('NEET_SESSION_ACTIVE');
                        setLoading(false);
                        return;
                    }
                }
            }

            // On success, we navigate to root. 
            // The AuthProvider and ProtectedRoute/LoginRedirect will take over 
            // and show the loading spinner until the profile is ready.
            navigate('/', { replace: true });
        } catch (err) {
            console.error("Login Error:", err);
            sessionStorage.removeItem('NEET_SESSION_ACTIVE');
            const msg = err.code === 'auth/user-not-found' ? "Account not found." :
                err.code === 'auth/wrong-password' ? "Incorrect password." :
                    "Invalid email or password.";
            showToast(msg);
            setLoading(false);
        }
    };

    return (
        <>
            <div className="auth-container">
                <div className="auth-card">
                    {/* Left Side: Slideshow */}
                    <div className="auth-slides-side">
                        {slides.map((slide, index) => (
                            <div key={index} className={`slide ${currentSlide === index ? 'active' : ''}`}>
                                {slide.image && (
                                    <img src={slide.image} alt="Slide" className="slide-img" />
                                )}
                                <div className={`slide-content ${slide.animClass}`}>
                                    <h3 className="slide-quote">{slide.quote}</h3>
                                    <div className="slide-stats">
                                        {slide.stats.map((stat, sIndex) => (
                                            <div key={sIndex} className="stat-item">
                                                <h4>{stat.value}</h4>
                                                <p>{stat.label}</p>
                                            </div>
                                        ))}
                                    </div>
                                </div>
                            </div>
                        ))}
                    </div>

                    {/* Right Side: Form */}
                    <div className="auth-form-side">
                        <div className="auth-form-inner">
                            <div className="auth-header">
                                <div className="auth-logo">
                                    <img src="/logo.png" alt="Sri Chaitanya" />
                                </div>
                                <h2>Login</h2>
                                <p>Enter your credentials to access the dashboard</p>
                            </div>

                            {/* Toast handles errors now */}

                            <form onSubmit={handleLogin}>
                                <div className="form-group">
                                    <label>Email Address</label>
                                    <div className="input-with-icon">
                                        <Mail size={18} className="icon" />
                                        <input
                                            type="email"
                                            placeholder="name@college.com"
                                            value={email}
                                            onChange={(e) => setEmail(e.target.value)}
                                            required
                                        />
                                    </div>
                                </div>

                                <div className="form-group">
                                    <label>Password</label>
                                    <div className="input-with-icon">
                                        <Lock size={18} className="icon" />
                                        <input
                                            type="password"
                                            placeholder="••••••••"
                                            value={password}
                                            onChange={(e) => setPassword(e.target.value)}
                                            required
                                        />
                                    </div>
                                </div>

                                <button type="submit" className="btn-auth" disabled={loading}>
                                    {loading ? "Authenticating..." : "Login to Dashboard"}
                                    {!loading && <ArrowRight size={18} />}
                                </button>
                            </form>

                            <div className="auth-footer">
                                New Principal?
                                <Link to="/register" className="btn-secondary-link">
                                    Register here
                                </Link>
                            </div>

                            <div className="admin-hint">
                                <ShieldCheck size={14} /> Admin Access Available
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <AnimatePresence>
                {toast && (
                    <Toast
                        message={toast.message}
                        type={toast.type}
                        onClose={() => setToast(null)}
                    />
                )}
            </AnimatePresence>

            <Modal
                isOpen={modal.isOpen}
                onClose={() => setModal({ ...modal, isOpen: false })}
                title={modal.title}
                message={modal.message}
                type={modal.type}
                confirmText="Understood"
            />
        </>
    );
};

export default LoginPage;
